#!/usr/bin/env python
# coding: utf-8

# In[254]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages


# In[297]:


data=pd.read_csv("DS_DATESET.csv")


# In[287]:


data_pd=pd.DataFrame(data)


# In[153]:


data_pd.columns = ['First_Name','Last_Name','City','State','Zip_Code','DOB','Age','Gender','Email_Address','Contact_Number','Emergency_Contact_Number','College_name','University_Name','Degree','Area_of_Study','Course_Type','Which_year_are_you_studying_in','CGPA','Expected_Graduation_year','Areas_of_interest','Current_Employment_Status','Have_you_worked_core_Java','Programming_Language_Known_other_than_Java','Have_you_worked_on_MySQL_or_Oracle_database','Have_you_studied_OOP_Concepts','Certifications_or_Achievement_or_Research_papers','Rate_your_written_communication_skills','Rate_your_verbal_communication_skills','Link_to_updated_Resume' ,'link_to_Linkedin_profile','How_Did_You_Hear_About_This_Internship','Label']


# In[ ]:





# ## The number of students applied to different technologies.

# In[25]:


l1=data_pd[data_pd.Programming_Language_Known_other_than_Java == 'HTML/CSS']


# In[26]:


l2=data_pd[data_pd.Programming_Language_Known_other_than_Java == 'PHP']


# In[27]:


l3=data_pd[data_pd.Programming_Language_Known_other_than_Java == 'C']


# In[28]:


l4=data_pd[data_pd.Programming_Language_Known_other_than_Java == 'Python']


# In[29]:


l5=data_pd[data_pd.Programming_Language_Known_other_than_Java == 'C++']


# In[48]:


l6=data_pd[data_pd.Programming_Language_Known_other_than_Java == '.Net']
l7=data_pd[data_pd.Programming_Language_Known_other_than_Java == 'JavaScript']
l8=data_pd[data_pd.Programming_Language_Known_other_than_Java == 'C#']
l9=data_pd[data_pd.Programming_Language_Known_other_than_Java == 'C']


# In[ ]:





# In[51]:


lang=['HTML/CSS','PHP','C','Python','C++','.Net','JavaScript','C#','C']


# In[35]:


len(l1)


# In[36]:


len(l2)


# In[38]:


len(l3)


# In[40]:


len(l4)


# In[41]:


len(l5)


# In[42]:


len(l6)


# In[43]:


len(l7)


# In[50]:


len(l8)


# In[45]:


len(l9)


# In[53]:


num=[1223,1203,1268,1224,1249,1274,1296,1263,1268]


# In[269]:


figa,ax=plt.subplots(figsize=(6,6))
ax.bar(lang,num)
plt.title('Number of students for each language')
plt.xlabel('Language')
plt.ylabel('Number of students')
plt.show()


# ## The different ways students learned about this program.

# In[64]:


p1=data_pd[data_pd.How_Did_You_Hear_About_This_Internship == 'Twitter']
p2=data_pd[data_pd.How_Did_You_Hear_About_This_Internship == 'Ex/Current Employee']
p3=data_pd[data_pd.How_Did_You_Hear_About_This_Internship == 'Facebook']
p4=data_pd[data_pd.How_Did_You_Hear_About_This_Internship == 'Newspaper']
p5=data_pd[data_pd.How_Did_You_Hear_About_This_Internship == 'Blog post']
p6=data_pd[data_pd.How_Did_You_Hear_About_This_Internship == 'Intern']
p7=data_pd[data_pd.How_Did_You_Hear_About_This_Internship == 'LinkedIn']
p8=data_pd[data_pd.How_Did_You_Hear_About_This_Internship == 'Friend']
p9=data_pd[data_pd.How_Did_You_Hear_About_This_Internship == 'Other']


# In[65]:


len(p1)


# In[67]:


len(p2)


# In[68]:


len(p3)


# In[70]:


len(p4)


# In[71]:


len(p5)


# In[72]:


len(p6)


# In[73]:


len(p7)


# In[74]:


len(p8)


# In[75]:


len(p9)


# In[76]:


med=['Twitter','Ex/Current Employee','Facebook','Newspaper','Blog Post','Intern','LinkedIn','Friend','Other']


# In[77]:


num1=[1160,1007,1084,1132,1116,1173,1112,1109,1077]


# In[291]:


figc,ax=plt.subplots(figsize=(12,6))
ax.bar(med,num1)
plt.title('Number of students for each medium')
plt.xlabel('Medium')
plt.ylabel('Number of students')
plt.show()


# ## Students who are in the fourth year and have a CGPA greater than 8.0.

# In[88]:


ab=data_pd[data_pd.Which_year_are_you_studying_in=='Fourth-year']


# In[90]:


gt8=ab[ab.CGPA > 8.00]


# In[280]:


figd,ax=plt.subplots(figsize=(6,6))
labels = 'Fourth_year_and_greater_than_8cg','remaining_students'
sizes = [1697,8303]
colors = ['lightcoral', 'lightskyblue']
patches, texts = plt.pie(sizes, colors=colors, shadow=True, startangle=90)
plt.legend(patches, labels, loc="upper right")
plt.pie(sizes, colors=colors, autopct='%1.1f%%', shadow=True, startangle=140)
plt.axis('equal')
plt.show()


# ## Year-wise and area of study wise classification of students.

# In[286]:


figf,ax= plt.subplots(2,2, subplot_kw=dict(aspect="equal"))
figf.set_size_inches(12,8)

plt.suptitle('Year-wise and area of study wise students',size=20,x=0.7,y=0.9)

dl1=data_pd[data_pd['Which_year_are_you_studying_in']=='First-year']
dl2=data_pd[data_pd['Which_year_are_you_studying_in']=='Second-year']
dl3=data_pd[data_pd['Which_year_are_you_studying_in']=='Third-year']
dl4=data_pd[data_pd['Which_year_are_you_studying_in']=='Fourth-year']
l1=list(dl1['Area_of_Study'].value_counts())
l2=list(dl1['Area_of_Study'].value_counts().index)
ax[0,0].pie(l1,startangle=90,autopct='%1.1f%%', shadow=True,colors=['royalblue','dodgerblue','skyblue'],radius=1)
ax[0,0].set_title("First-year students")
l3=list(dl2['Area_of_Study'].value_counts())
l4=list(dl2['Area_of_Study'].value_counts().index)
ax[0,1].pie(l3,startangle=90,autopct='%1.1f%%', shadow=True,colors=['olive','y','limegreen'])
ax[0,1].set_title("Second-year students")
l5=list(dl3['Area_of_Study'].value_counts())
l6=list(dl3['Area_of_Study'].value_counts().index)
ax[1,0].pie(l5,startangle=90,autopct='%1.1f%%', shadow=True,colors=['darksalmon','firebrick','mistyrose'])
ax[1,0].set_title("Third-year students")
l7=list(dl4['Area_of_Study'].value_counts())
l8=list(dl4['Area_of_Study'].value_counts().index)
ax[1,1].pie(l7,startangle=90,autopct='%1.1f%%', shadow=True,colors=['mediumvioletred','palevioletred','pink'])
ax[1,1].set_title("Fourth-year students")
ax[0,0].legend(l2,loc='best',bbox_to_anchor=(1.005,1.005))
ax[0,1].legend(l4,loc='best',bbox_to_anchor=(1.005,1.005))
ax[1,0].legend(l6,loc='best',bbox_to_anchor=(1.005,1.005))
ax[1,1].legend(l8,loc='best',bbox_to_anchor=(1.005,1.005))

plt.subplots_adjust(left=0.2, bottom=0.1, right=1.2,top=0.8)
plt.show()


# ## The number of students applied for Data Science who knew ‘’Python” and who didn’t.

# In[142]:


ds=data_pd[data_pd.Areas_of_interest=='Data Science ']


# In[145]:


know_python=ds[ds.Programming_Language_Known_other_than_Java=='Python']


# In[281]:


figb,ax=plt.subplots(figsize=(6,6))
labels = 'Know Python','Dont know Python'
sizes = [66,601]
colors = ['lightcoral', 'lightskyblue']
patches, texts = plt.pie(sizes, colors=colors, shadow=True, startangle=90)
plt.legend(patches, labels, loc="best")
plt.pie(sizes, colors=colors, autopct='%1.1f%%', shadow=True, startangle=140)
plt.axis('equal')
plt.title('Coparison between students of Data Science who know Python and who dont know Python')
plt.show()


# ## City and college wise classification of students

# In[261]:


theme = plt.get_cmap('spring')
figg,ax= plt.subplots(3,2, subplot_kw=dict(aspect="equal"),sharex=True)
figg.set_size_inches(15,10)
plt.suptitle('City wise and College wise Classification',size=20,x=0.5,y=0.9)
c1=data_pd[data_pd['City']=='Kolhapur']
c2=data_pd[data_pd['City']=='Pune']
c3=data_pd[data_pd['City']=='Mumbai']
c4=data_pd[data_pd['City']=='Solapur']
c5=data_pd[data_pd['City']=='Sangli']
c6=data_pd[data_pd['City']=='NaviMumbai']
plt.subplots_adjust(left=0.0, bottom=0.1, right=0.8,top=0.8)
ax[0,0].pie(list(c1['College_name'].value_counts()),startangle=90,autopct='%1.1f%%', shadow=True)

ax[0,1].pie(list(c2['College_name'].value_counts()),startangle=90,autopct='%1.1f%%', shadow=True)
ax[1,0].pie(list(c3['College_name'].value_counts()),startangle=90,autopct='%1.1f%%', shadow=True)
ax[1,1].pie(list(c4['College_name'].value_counts()),startangle=90,autopct='%1.1f%%', shadow=True)
ax[2,0].pie(list(c5['College_name'].value_counts()),startangle=90,autopct='%1.1f%%', shadow=True)
ax[2,1].pie(list(c6['College_name'].value_counts()),startangle=90,autopct='%1.1f%%', shadow=True)
ax[0,0].legend(c1['College_name'].value_counts().index,loc='best',bbox_to_anchor=(1.005,1.005))
ax[0,1].legend(c2['College_name'].value_counts().index,loc='best',bbox_to_anchor=(1.005,1.005))
ax[1,0].legend(c3['College_name'].value_counts().index,loc='best',bbox_to_anchor=(1.005,1.005))
ax[1,1].legend(c4['College_name'].value_counts().index,loc='best',bbox_to_anchor=(1.005,1.005))
ax[2,0].legend(c5['College_name'].value_counts().index,loc='best',bbox_to_anchor=(1.005,1.005))
ax[2,1].legend(c6['College_name'].value_counts().index,loc='best',bbox_to_anchor=(1.005,0.8))
ax[0,0].set_title('Students of Kolhapur')
ax[0,1].set_title('Students of Pune')
ax[1,0].set_title('Students of Mumbai')
ax[1,1].set_title('Students of Solapur')
ax[2,0].set_title('Students of Sangli')
ax[2,1].set_title('Students of NaviMumbai')
plt.show()


# ## Students who applied for Digital Marketing with verbal and written communication score greater than 8.

# In[229]:


dm=data_pd[data_pd.Areas_of_interest=='Digital Marketing ']


# In[238]:


dm=dm[dm.Rate_your_verbal_communication_skills>8]


# In[233]:


dm=dm[dm.Rate_your_written_communication_skills>8]


# In[277]:


fige,ax=plt.subplots(figsize=(6,6))
labels = 'Classified students','others'
sizes = [92,9908]
colors = ['lightcoral','gold']
patches, texts = plt.pie(sizes, colors=colors, shadow=True, startangle=90)

plt.legend(patches, labels, loc="upper right")
plt.pie(sizes, colors=colors, autopct='%1.1f%%', shadow=True, startangle=140)
plt.axis('equal')
plt.title('Students who applied for Digital Marketing with verbal and written communication score greater than 8')
#plt.show()


# ## Plot the relationship between the CGPA and the target variable 

# In[246]:


import seaborn as sns
sns.set(style="darkgrid", context="notebook")
figh,ax=plt.subplots(figsize=(8,8))
plt.suptitle('Relationship between CGPA and eligibility',size=20,x=0.7,y=0.9)
plt.subplots_adjust(left=0.2, bottom=0.1, right=1.2,top=0.8)
x=sns.boxplot(x='CGPA',y='Which_year_are_you_studying_in',hue='Label',data=data_pd,dodge=True,order=['First-year','Second-year','Third-year','Fourth-year'],palette='Set2')
x.legend(bbox_to_anchor=(1.05,1),loc=2,borderaxespad=0.)


# ## Plot the relationship between the Area of Interest and the target variable

# In[247]:


figi,ax=plt.subplots(figsize=(8,8))
plt.suptitle('Relationship between Areas of Interest and eligibility',size=20,x=0.7,y=0.9)
plt.subplots_adjust(left=0.2, bottom=0.1, right=1.2,top=0.8)

g=sns.countplot(y='Areas_of_interest',hue='Label',data=data_pd,edgecolor=(0,0,0),linewidth=2,palette='Paired')
g.legend(bbox_to_anchor=(1.05,1),loc=2,borderaxespad=0.)


# In[293]:


figj,ax= plt.subplots(2,2)
figj.set_size_inches(14,5)
plt.suptitle('Relationship between year,major and eligibility',size=25,x=0.5,y=1.1)
plt.subplots_adjust(left=0, bottom=0.2, right=1.5,top=1)

sns.countplot(x='Area_of_Study',hue='Label',data=dl1,ax=ax[0,0],edgecolor=(0,0,0),linewidth=2,palette='Pastel1')
ax[0,0].set_title('First Year Students',fontsize=18)
sns.countplot(x='Area_of_Study',hue='Label',data=dl2,ax=ax[0,1],edgecolor=(0,0,0),linewidth=2,palette='Pastel1')
ax[0,1].set_title('Second Year Students',fontsize=18)
sns.countplot(x='Area_of_Study',hue='Label',data=dl3,ax=ax[1,0],edgecolor=(0,0,0),linewidth=2,palette='Pastel1')
ax[1,0].set_title('Third Year Students',fontsize=18)
sns.countplot(x='Area_of_Study',hue='Label',data=dl4,ax=ax[1,1],edgecolor=(0,0,0),linewidth=2,palette='Pastel1')
ax[1,1].set_title('Fourth Year Students',fontsize=18)
figj.tight_layout(pad=0.5)


# In[294]:


with PdfPages('Output.pdf') as pdf:
    pdf.savefig(figa,bbox_inches='tight')
    pdf.savefig(figb,bbox_inches='tight')
    pdf.savefig(figc,bbox_inches='tight')
    pdf.savefig(figd,bbox_inches='tight')
    pdf.savefig(fige,bbox_inches='tight')
    pdf.savefig(figf,bbox_inches='tight')
    pdf.savefig(figg,bbox_inches='tight')
    pdf.savefig(figh,bbox_inches='tight')
    pdf.savefig(figi,bbox_inches='tight')
    pdf.savefig(figj,bbox_inches='tight')


# In[ ]:





# # Binary Classification of the dataset

# In[298]:


df=data


# In[309]:


import sklearn as sk
from sklearn.metrics import f1_score
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import cross_validate
from sklearn.model_selection import train_test_split


# In[299]:


import warnings
warnings.filterwarnings("ignore")

features=['Gender','Major/Area of Study','Which-year are you studying in?','CGPA/ percentage',
          'Have you worked core Java',
       'Have you worked on MySQL or Oracle database',
      'Have you studied OOP Concepts',
      'Rate your written communication skills [1-10]',
       'Rate your verbal communication skills [1-10]']
x=df[features]

y=pd.get_dummies(df['Label']).drop(['ineligible'],axis=1)
y=np.ravel(y)


# In[300]:



encode={"Gender": {'Male': 0, 'Female': 1 },
"Which-year are you studying in?": {'First-year':1,'Second-year':2,'Third-year':3,'Fourth-year':4},
'Have you worked core Java':{'Yes':1,'No':0},
'Have you worked on MySQL or Oracle database':{'Yes':1,'No':0},
'Have you studied OOP Concepts':{'Yes':1,'No':0},
'Major/Area of Study':{'Computer Engineering':1,'Electrical Engineering':2,'Electronics and Telecommunication':3}}
x.replace(encode, inplace=True)

x['CGPA/ percentage'].fillna(x['CGPA/ percentage'].mean(),inplace=True)
x['Rate your written communication skills [1-10]'].fillna(x['Rate your written communication skills [1-10]'].median(),inplace=True)
x['Rate your verbal communication skills [1-10]'].fillna(x['Rate your verbal communication skills [1-10]'].median(),inplace=True)
x['Have you worked on MySQL or Oracle database'].fillna(x['Have you worked on MySQL or Oracle database'].median(),inplace=True)
x['Have you studied OOP Concepts'].fillna(x['Have you studied OOP Concepts'].median(),inplace=True)
x['Have you worked core Java'].fillna(x['Have you worked core Java'].median(),inplace=True)
x['Which-year are you studying in?'].fillna(x['Which-year are you studying in?'].median(),inplace=True)
x['Major/Area of Study'].fillna(x['Major/Area of Study'].median(),inplace=True)
x['Gender'].fillna(x['Gender'].median(),inplace=True)
x.isna().sum()


# In[302]:



F1_score={}
X_train, X_test, y_train, y_test = train_test_split(x,y,test_size=0.2,random_state=100)


# In[303]:


LR = LogisticRegression()
LR.fit(X_train,y_train)
lrpreds=LR.predict(X_train)
LR_f1 = f1_score(y_train,lrpreds)
F1_score['Logistic Regression']= LR_f1


# In[304]:


F1_score


# In[305]:


SVM = SVC(probability = True)
SVM.fit(X_train,y_train)
svpreds=SVM.predict(X_train)
SVM_f1 = f1_score(y_train,svpreds)
F1_score['Support Vector Machine']= SVM_f1


# In[306]:


F1_score


# In[307]:


KNN = KNeighborsClassifier()
KNN.fit(X_train,y_train)
kpreds=KNN.predict(X_train)
KNN_f1 = f1_score(y_train,kpreds)
F1_score['K-Nearest Neighbors']= KNN_f1


# In[308]:


F1_score


# In[312]:


accuracy=max(F1_score.values())


# In[319]:


accuracy=accuracy*100


# In[326]:


print("Accuracy of the model: %.2f" %accuracy)







